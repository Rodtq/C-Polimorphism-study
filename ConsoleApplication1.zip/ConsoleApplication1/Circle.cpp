#pragma once
#include "Circle.h"
#include <iostream>

Circle::Circle() {};
Circle::~Circle() {};


void Circle::PrintShape() {
	std::cout << "Hi, I'm The Circle 0" << std::endl;
};