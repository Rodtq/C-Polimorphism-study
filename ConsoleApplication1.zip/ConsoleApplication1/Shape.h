#pragma once

class Shape
{
public:
	virtual void PrintShape() {};
private:

};
