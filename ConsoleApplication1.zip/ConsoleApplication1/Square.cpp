
#include "Square.h"
#include <iostream>
Square::Square()
{

};

Square::~Square()
{

};

void Square::PrintShape() {
	std::cout << "Hi, I'm The Square []" << std::endl;
};